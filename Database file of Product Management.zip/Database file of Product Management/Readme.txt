---------------Product Management---------------

Database Name - selln
Table Name    - products